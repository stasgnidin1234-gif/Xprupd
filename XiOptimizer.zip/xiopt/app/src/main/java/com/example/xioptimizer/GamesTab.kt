package com.example.xioptimizer

import android.Manifest
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun TurboStatusCard() {
    val context = LocalContext.current
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🎮 Game Turbo", style = MaterialTheme.typography.titleMedium)
            if (TurboState.active) {
                Text(
                    "Активен: ${TurboState.gameLabel}\n${TurboState.message}",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onClick = { GameTurbo.requestStop(context) }) {
                    Text("Выключить и вернуть всё")
                }
            } else {
                Text(
                    "Выключен. Запусти игру из вкладки «Игры», и всё лишнее закроется на время игры.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun GamesTab(state: AppState, turbo: TurboPrefs) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<Pair<String, String>>()) }
    var detected by remember { mutableStateOf(emptySet<String>()) }
    var query by remember { mutableStateOf("") }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.Default) {
            val list = loadApps(context)
            val pm = context.packageManager
            val games = list.filter { (_, pkg) ->
                try {
                    pm.getApplicationInfo(pkg, 0).category == ApplicationInfo.CATEGORY_GAME
                } catch (e: Exception) {
                    false
                }
            }.map { it.second }.toSet()
            apps = list
            detected = games
        }
    }

    val labels = apps.associate { it.second to it.first }
    val canStart = state.shizukuReady && !state.busy && !TurboState.active

    fun start(pkg: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        GameTurbo.launch(context, pkg)
    }

    val suggestions = apps.filter { it.second in detected && it.second !in turbo.games }.take(10)
    val matches = if (query.length >= 2) {
        apps.filter {
            (it.first.contains(query, ignoreCase = true) ||
                it.second.contains(query, ignoreCase = true)) && it.second !in turbo.games
        }.take(6)
    } else {
        emptyList()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("Игры и Game Turbo", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Запускай игру отсюда. Turbo закроет остальные приложения и включит максимум, " +
                        "а когда выйдешь из игры, сам вернёт всё как было.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        item { ShizukuCard(state) }
        item { TurboStatusCard() }

        item { Text("Что делает Turbo", style = MaterialTheme.typography.titleMedium) }
        item {
            SwitchCard(
                title = "Закрыть все остальные приложения",
                description = "Останавливает все сторонние приложения кроме игры, клавиатуры, лаунчера и Shizuku и запрещает им фон на время игры. Мессенджеры не будут присылать уведомления.",
                checked = turbo.closeApps,
                onChange = { turbo.updateCloseApps(it) }
            )
        }
        item {
            SwitchCard(
                title = "Не беспокоить",
                description = "Включает режим «Не беспокоить» на время игры. Звонки из избранного проходят.",
                checked = turbo.dnd,
                onChange = { turbo.updateDnd(it) }
            )
        }
        item {
            SwitchCard(
                title = "Режим производительности игры",
                description = "Просит систему включить режим максимальной производительности для этой игры (Android 12+).",
                checked = turbo.gameMode,
                onChange = { turbo.updateGameMode(it) }
            )
        }
        item {
            SwitchCard(
                title = "Ускорение интерфейса и экрана",
                description = "На время игры: быстрые анимации, 120 Гц, без фонового поиска сетей. После игры вернётся то, что ты сам включал в «Функциях».",
                checked = turbo.tweaks,
                onChange = { turbo.updateTweaks(it) }
            )
        }

        item { Text("Мои игры", style = MaterialTheme.typography.titleMedium) }

        if (turbo.games.isEmpty()) {
            item {
                Text(
                    "Пока пусто. Добавь игры ниже.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        items(turbo.games.toList().sortedBy { (labels[it] ?: it).lowercase() }) { pkg ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(labels[pkg] ?: pkg, style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = canStart, onClick = { start(pkg) }) {
                            Text("Запустить с Turbo")
                        }
                        TextButton(onClick = { turbo.removeGame(pkg) }) { Text("Убрать") }
                    }
                }
            }
        }

        item { Text("Добавить игру", style = MaterialTheme.typography.titleMedium) }

        if (suggestions.isNotEmpty()) {
            item {
                Text(
                    "Найдено автоматически:",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            items(suggestions) { (label, pkg) ->
                TextButton(
                    onClick = { turbo.addGame(pkg) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("＋ $label", maxLines = 1) }
            }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Найти приложение по названию") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        items(matches) { (label, pkg) ->
            TextButton(
                onClick = {
                    turbo.addGame(pkg)
                    query = ""
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("＋ $label  ($pkg)", maxLines = 1) }
        }
    }
}
